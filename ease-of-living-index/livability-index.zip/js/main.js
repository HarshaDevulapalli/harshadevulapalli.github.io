var sliderValues = [10,10,10,10,10,10,10,10,10,10];
$(document).ready(function () {
		calculateResults();
		$('[data-toggle="tooltip"]').tooltip();	  
});
